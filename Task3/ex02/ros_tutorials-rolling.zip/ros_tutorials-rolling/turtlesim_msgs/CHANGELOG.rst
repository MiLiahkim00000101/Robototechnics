^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlesim_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.10.2 (2025-10-03)
-------------------
* fix cmake deprecation (`#182 <https://github.com/ros/ros_tutorials/issues/182>`_)
* Contributors: mosfet80

1.10.1 (2025-05-26)
-------------------

1.10.0 (2025-04-25)
-------------------

1.9.2 (2024-07-09)
------------------
* Create turtlesim_msgs (`#169 <https://github.com/ros/ros_tutorials/issues/169>`_)
* Contributors: Alejandro Hernández Cordero
